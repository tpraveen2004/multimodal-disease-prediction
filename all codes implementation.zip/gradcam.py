import torch
import torch.nn.functional as F
import cv2
import numpy as np

def generate_gradcam(model, inputs, target_layer):
    """
    inputs = (image_tensor, ehr_tensor)
    """
    image, ehr = inputs
    image.requires_grad = True

    activations = []
    gradients = []

    # Hooks
    def forward_hook(module, inp, out):
        activations.append(out)

    def backward_hook(module, grad_in, grad_out):
        gradients.append(grad_out[0])

    # Register hooks
    target_layer.register_forward_hook(forward_hook)
    target_layer.register_backward_hook(backward_hook)

    # Forward pass
    # Forward pass
    logits, _, _, _ = model(image, ehr)

# Apply sigmoid for multi-label
    probs = torch.sigmoid(logits)

# Take most confident class
    pred_class = probs.argmax()

    # Backward pass
    model.zero_grad()
    logits[0, pred_class].backward()

    # Convert to CAM
    act = activations[0]                 # (1, C, H, W)
    grad = gradients[0].mean(dim=[2,3], keepdim=True)

    cam = (act * grad).sum(dim=1).squeeze().cpu().detach().numpy()
    cam = np.maximum(cam, 0)
    cam /= cam.max()

    # Resize to image size
    cam = cv2.resize(cam, (256, 256))

    return cam
