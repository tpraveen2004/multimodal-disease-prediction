import torch.nn as nn
from .image_encoder import ImageEncoder
from .ehr_encoder import EHREncoder
from .fusion_attention import AttentionFusion

class MultimodalModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.img_enc = ImageEncoder(output_dim=256)
        self.ehr_enc = EHREncoder(input_dim=4, hidden_dim=32, output_dim=64)
        self.fusion = AttentionFusion(img_dim=256, ehr_dim=64, fusion_dim=128)

    def forward(self, img, ehr):
        img_feat = self.img_enc(img)
        ehr_feat = self.ehr_enc(ehr)
        logits, weights = self.fusion(img_feat, ehr_feat)
        return logits, weights, img_feat, ehr_feat
