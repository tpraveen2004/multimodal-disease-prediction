import torch
import torch.nn.functional as F

def compute_metrics(outputs, targets):
    outputs = torch.sigmoid(outputs).detach().cpu().numpy()
    targets = targets.cpu().numpy()

    metrics = {}
    metrics["accuracy"] = ((outputs > 0.5) == targets).mean()

    return metrics

def train_one_epoch(model, dataloader, optimizer, device):
    model.train()
    total_loss = 0

    for img, ehr, target in dataloader:
        img, ehr, target = img.to(device), ehr.to(device), target.to(device)

        optimizer.zero_grad()
        out, _, _, _ = model(img, ehr)

        loss = F.binary_cross_entropy_with_logits(out, target)
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    return total_loss / len(dataloader)
