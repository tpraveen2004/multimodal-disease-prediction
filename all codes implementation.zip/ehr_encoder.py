import torch
import torch.nn as nn

class EHREncoder(nn.Module):
    def __init__(self, input_dim=4, hidden_dim=32, output_dim=64):
        super(EHREncoder, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
            nn.ReLU()
        )
        
    def forward(self, x):
        return self.net(x)
