import torch
from torch.utils.data import DataLoader
from models.multimodal_model import MultimodalModel
from training.utils import train_one_epoch
from covid_dataloader import CovidXrayDataset

device = "cuda" if torch.cuda.is_available() else "cpu"

def train_model():
    dataset = CovidXrayDataset(
        image_dir="../data/covid_xray/images",
        metadata_path="../data/covid_xray/metadata.csv",
        label_map_path="disease_labels.json"
    )

    loader = DataLoader(dataset, batch_size=8, shuffle=True)

    model = MultimodalModel().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)

    for epoch in range(2):  # Increase later
        loss = train_one_epoch(model, loader, optimizer, device)
        print(f"Epoch {epoch+1}: Loss = {loss:.4f}")

    torch.save(model.state_dict(), "multimodal_model.pth")

if __name__ == "__main__":
    train_model()
