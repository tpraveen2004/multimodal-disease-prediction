import torch
import torch.nn as nn

class AttentionFusion(nn.Module):
    def __init__(self, img_dim=256, ehr_dim=64, fusion_dim=128):
        super().__init__()
        self.att_img = nn.Linear(img_dim, fusion_dim)
        self.att_ehr = nn.Linear(ehr_dim, fusion_dim)
        self.softmax = nn.Softmax(dim=1)

        self.classifier = nn.Sequential(
            nn.Linear(fusion_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 5)  # 5 diseases
        )

    def forward(self, img_feat, ehr_feat):
        img_att = self.att_img(img_feat)
        ehr_att = self.att_ehr(ehr_feat)

        weights = self.softmax(torch.stack([img_att, ehr_att], dim=1))
        fused = (weights[:,0] * img_att) + (weights[:,1] * ehr_att)

        logits = self.classifier(fused)
        return logits, weights
